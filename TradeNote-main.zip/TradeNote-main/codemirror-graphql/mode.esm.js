import CodeMirror from 'codemirror';
import modeFactory from './utils/mode-factory';
CodeMirror.defineMode('graphql', modeFactory);
//# sourceMappingURL=mode.js.map