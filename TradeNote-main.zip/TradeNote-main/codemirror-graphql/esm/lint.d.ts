export {};
//# sourceMappingURL=lint.d.ts.map