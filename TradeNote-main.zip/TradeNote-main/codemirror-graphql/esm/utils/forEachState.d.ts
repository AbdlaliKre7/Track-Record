import type { State } from 'graphql-language-service';
export default function forEachState(stack: State, fn: (state: State) => void): void;
//# sourceMappingURL=forEachState.d.ts.map