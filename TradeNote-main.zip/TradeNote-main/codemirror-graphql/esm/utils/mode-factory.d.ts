import CodeMirror from 'codemirror';
declare const graphqlModeFactory: CodeMirror.ModeFactory<any>;
export default graphqlModeFactory;
//# sourceMappingURL=mode-factory.d.ts.map