<script setup>
import LoginRegister from '../components/LoginRegister.vue'
</script>

<template>
    <LoginRegister />
</template>
